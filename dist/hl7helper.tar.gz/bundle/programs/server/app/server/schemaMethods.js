(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/schemaMethods.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
    'saveSchema': function (doc) {                                     // 2
        if (!doc.creator) {                                            // 3
            doc.creator = this.userId;                                 // 3
        }                                                              //
        var schema = Collections.Schemas.upsert(doc._id, { $set: { name: doc.name, segments: doc.segments, creator: doc.creator } });
        console.log(schema);                                           // 5
        return schema.insertedId || doc._id;                           // 6
    },                                                                 //
    'deleteSchema': function (doc) {                                   // 8
        if (doc.creator === this.userId) {                             // 9
            Collections.Schemas.remove({ _id: doc._id });              // 10
            return doc._id;                                            // 11
        } else {                                                       //
            return "You do not have permission to delete that schema.";
        }                                                              //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=schemaMethods.js.map
