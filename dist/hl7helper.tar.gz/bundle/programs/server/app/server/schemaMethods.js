(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/schemaMethods.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
    'saveSchema': function (doc) {                                     // 2
        if (!doc.creator) {                                            // 3
            doc.creator = this.userId;                                 // 3
        }                                                              //
        var schema = Collections.Schemas.upsert(doc._id, { $set: { name: doc.name, segments: doc.segments, creator: doc.creator } });
        console.log(schema);                                           // 5
        return schema.insertedId || doc._id;                           // 6
    },                                                                 //
    'deleteSchema': function (doc) {                                   // 8
        if (doc.creator === this.userId) {                             // 9
            Collections.Schemas.remove({ _id: doc._id });              // 10
            return doc._id;                                            // 11
        } else {                                                       //
            return "You do not have permission to delete that schema.";
        }                                                              //
    },                                                                 //
    'toggleSchemaFavorite': function (schema) {                        // 17
        var isFavorite = Collections.Favorites.findOne({ schema: schema._id, user: this.userId }) ? true : false;
        if (isFavorite) {                                              // 19
            Collections.Favorites.remove({ schema: schema._id, user: this.userId });
            return "Favorite Deleted";                                 // 21
        } else {                                                       //
            Collections.Favorites.insert({ schema: schema._id, user: this.userId });
            return "Favorite Added";                                   // 25
        }                                                              //
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=schemaMethods.js.map
