(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('schemas', function () {                                // 1
	return Collections.Schemas.find({});                                  // 2
});                                                                    //
                                                                       //
Meteor.publish('favorites', function () {                              // 5
	return Collections.Favorites.find({});                                // 6
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
